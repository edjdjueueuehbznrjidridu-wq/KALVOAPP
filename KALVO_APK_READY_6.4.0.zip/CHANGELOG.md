# KALVO Market Lab — Changelog

## 6.3.0 — Multi-asset market core
- Added global spot gold/silver, Iranian 18K gold and 999/925 silver, WTI/Brent spot references, and separate gold/silver/oil futures demo symbols.
- Added a validated Tabloo/TGJU fallback for global XAU/XAG quotes when Gold-API fails; currency and troy-ounce units are checked before use.
- Added a canonical instrument catalogue, public read-only providers, native quote units, source/time/status metadata, and commodity-aware wallet marks.
- Added Iranian metal pricing fallback: global troy-ounce quote × local USD/IRT ÷ 31.1034768 × purity, with a configurable indicative 20 bps adjustment.
- Added Wallex public USDT/Toman reference feed; it is display/conversion-only and not tradable.
- Added quick commodity selectors in Spot and Futures and freshness labels in the Market Radar.
- Expanded AI context and Persian local knowledge for cross-asset units, spot/futures distinctions, Iranian gold formulas, oil barrels and data quality.
- Added FRED API key configuration and `.env` placeholders; no actual provider keys are bundled.
- Kept automatic scanners limited to crypto; commodities are manually paper-tradable only.
- Prevented oil spot history from silently substituting futures candles.
- Added unit and integration tests for catalogue, pricing, provider parsing, AI context and paper-only boundaries.

## 6.2.0 — Phase 1 foundation
- Product scope and architecture documentation rewritten around the Market Lab mission.
- Removed the bundled Coarena credential and implicit credential fallback.
- Added one-time targeted cleanup for the exact legacy bundled credential using a one-way fingerprint; unrelated user keys are preserved.
- Unsupported candle timeframes now fail explicitly instead of silently becoming `1hour`.
- Ticker responses now expose `observed_at`, `age_seconds`, `status` and `stale`; live-price reads reject stale snapshots.
- Aligned app version and Kivy dependency pins across metadata and Android build settings.
- Added GitHub Actions validation and Android debug APK workflow.
- Added tests for no-bundled-key behavior and invalid timeframe rejection.

## 6.1.0
- Event bus between price ticks, positions and wallet.
- Market order obtains a current price before opening a virtual position.
- Learning refresh after trade close and automatic scanning.
- AI gate default is advisory.
- Touch-oriented navigation and controls.

## 6.0.0
- Combined Market Lab with Hybrid AI and AI Core.
- Added market regime classification, drawdown governor, AI gate and decision audit.
- Added adaptive statistical memory and model scorecard.

## 5.4.0
- Added multi-timeframe analysis, local Persian knowledge base and weekly journal coach.
- Added optional cloud model integration.

## 4.2.0
- Added Strategy Lab, chronological validation, candle replay, weekly coach, portfolio analytics, scenario analysis and notification center.
- Added futures and spot paper trading controls and automatic demo scanners.

## 6.4.0 — Market Intelligence, FX discovery and premium UX
- Added a read-only TGJU `call2.tgju.org/ajax.json` adapter for verified Iranian open-market FX identifiers; source Rial is normalized to Toman (`p / 10`) at the adapter boundary.
- Expanded supported Iranian FX references (USD, EUR, GBP, AED, TRY, CAD, AUD, CNY, NZD, SGD, INR, PKR, IQD, SYP, AFN, DKK, SEK, NOK, SAR, QAR, OMR, KWD, BHD, MYR, THB, HKD, RUB, AZN, AMD, GEL, KGS, TJS, TMT) with explicit mapping and no fabricated CHF/JPY alias.
- Added FX spot instruments and clearly labelled synthetic educational futures references; these are not exchange-listed futures prices.
- Added implied `CODEUSD` cross pairs (e.g. `EURUSD`) by dividing the two TGJU Toman quotes; cross-pairs are explicitly labelled local implied rates, not global interbank FX.
- Added corresponding synthetic FX futures reference symbols ending in `F`, with the cash underlying and non-exchange status made explicit.
- Added shared/single-flight TGJU snapshots and a short USDT/Toman conversion cache to prevent parallel watchlist request storms.
- Kept native Toman quotes visible when the USDT ledger conversion is unavailable; such instruments are display-only and not paper-tradeable until a valid conversion exists.
- Updated symbol discovery to rank exact/prefix matches, attach native prices/units/status, and distinguish unsupported symbols from listed-but-unavailable quotes.
- Fixed Market Radar to retain native-quote-only rows instead of dropping them when ledger conversion fails.
- Refreshed the visual design system and persistent navigation with a midnight-navy/electric-blue/jade palette; added refined watchlist cards.
- Added a 100-phase product roadmap and updated market-source documentation.
- Added regression tests for TGJU FX, prefix search, native quote visibility and failed conversion handling.
- All trade operations remain local paper simulations; no live exchange order endpoints were added.
