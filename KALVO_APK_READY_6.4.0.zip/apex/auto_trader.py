# -*- coding: utf-8 -*-
"""KALVO paper-only multi-timeframe scanner.

The module is intentionally limited to the local virtual ledger. It does not
contain exchange order endpoints, account credentials, or live execution code.
"""
from __future__ import annotations

import math
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional

from . import analysis_engine as analysis
from . import market_apis as market
from . import storage as store
from . import learning as learning_engine
try:
    from . import learning_memory as mem
except Exception:
    mem = None
from . import ai_core
from . import instrument_catalog as instruments
from .config import get_env

WATCHLIST = ("BTC", "ETH", "SOL", "BNB", "XRP", "DOGE", "LINK", "AVAX", "ADA", "DOT")
TIMEFRAMES = ("15min", "1hour", "4hour")
MAX_AUTO_POSITIONS = 2
MAX_LEVERAGE = 2.0
COOLDOWN_SECONDS = 4 * 60 * 60


def _stored_number(key: str, default: float, low: float, high: float) -> float:
    try:
        value = float(store.get_setting(key, str(default)))
        if not math.isfinite(value):
            return default
        return max(low, min(high, value))
    except (TypeError, ValueError):
        return default


def get_auto_config() -> Dict[str, Any]:
    """Read and clamp the user's demo-only auto-scan preferences."""
    max_positions = int(_stored_number("auto_max_positions", 3, 1, 4))
    risk_pct = _stored_number("auto_risk_pct", 0.30, 0.10, 0.50)
    min_confluence = int(_stored_number("auto_min_confluence", 68, 60, 90))
    max_leverage = _stored_number("auto_max_leverage", 2.0, 1.0, 2.0)
    cooldown_hours = _stored_number("auto_cooldown_hours", 4, 1, 24)
    scan_interval = int(_stored_number("auto_scan_interval", 90, 60, 300))
    return {
        "max_positions": max_positions,
        "risk_pct": risk_pct,
        "min_confluence": min_confluence,
        "max_leverage": max_leverage,
        "cooldown_hours": cooldown_hours,
        "cooldown_seconds": int(cooldown_hours * 3600),
        "scan_interval": scan_interval,
        "max_margin_pct_per_position": 2.0,
        "max_free_cash_pct_per_position": 4.0,
    }


def _ai_gate_review(item: Dict[str, Any], assessment: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Optional cloud second opinion. Returns None when the gate is off/unconfigured.

    The cloud model may only approve, reduce or veto; failure never blocks or
    enlarges a trade (the local rules stand).
    """
    mode = (store.get_setting("ai_gate", "off") or "off").lower()
    if mode not in ("advisory", "veto", "autopilot"):
        return None
    key = (store.get_setting("coarena_api_key", "") or get_env("COARENA_API_KEY") or "").strip()
    if len(key) < 8:
        if mode == "autopilot":  # fail-closed: no key -> no AI decision -> no entry
            return {"ok": False, "verdict": "unavailable", "confidence": 0,
                    "reason": "کلید Coarena تنظیم نشده", "mode": mode}
        return None
    try:
        from . import hybrid_ai
        hourly = item["timeframes"]["1hour"]
        ctx = hybrid_ai.build_context_block(
            symbol=item["symbol"], analysis=hourly,
            ticker={"price": item.get("price"), "source": item.get("ticker_source")},
            positions=None, wallet=None, share_account=False)
        out = hybrid_ai.cloud_gate(
            key, store.get_setting("coarena_model", ""), ctx, item["symbol"],
            item["consensus"]["direction"], int(item.get("score") or 0),
            assessment.get("regime_label", ""), autopilot=(mode == "autopilot"))
    except Exception as exc:  # noqa: BLE001
        out = {"ok": False, "verdict": "unavailable", "confidence": 0,
               "reason": str(exc)[:80]}
    out["mode"] = mode
    return out


def _watch_symbols(symbols: Optional[List[str]]) -> List[str]:
    if symbols is not None:
        raw = symbols
        source = "explicit"
    else:
        saved = store.watchlist_list(20)
        raw = [row.get("symbol") for row in saved if row.get("symbol")] or list(WATCHLIST)
        source = "watchlist" if saved else "default"
    normalized: List[str] = []
    for item in raw:
        try:
            canonical = instruments.normalize_instrument_symbol(str(item))
            if instruments.is_instrument(canonical) or instruments.is_reference_symbol(canonical):
                continue
            base = market.normalize_symbol(str(item))[0]
        except (TypeError, ValueError):
            continue
        if base not in normalized:
            normalized.append(base)
        if len(normalized) >= 10:
            break
    if normalized:
        return normalized
    # An explicit or saved commodity-only watchlist must not silently fall back
    # to a different set of crypto symbols.
    return [] if source in ("explicit", "watchlist") else list(WATCHLIST)


def inspect_symbol(symbol: str, now: Optional[float] = None) -> Dict[str, Any]:
    """Return a transparent multi-timeframe readout; never opens a position."""
    current = float(now if now is not None else time.time())
    canonical = instruments.normalize_instrument_symbol(symbol)
    if instruments.is_instrument(canonical) or instruments.is_reference_symbol(canonical):
        return {"symbol": canonical, "ready": False,
                "reason": "اسکن خودکار فقط روی رمزارزهای دارای دادهٔ لحظه‌ای اجرا می‌شود؛ فلزات و نفت فعلاً دستی و دمو هستند."}
    ticker = market.get_ticker(symbol)
    price = ticker.get("price") if isinstance(ticker, dict) else None
    ticker_ts = float((ticker or {}).get("ts") or 0)
    if not price or ticker_ts <= 0 or current - ticker_ts > 45 or ticker_ts - current > 10:
        return {"symbol": symbol, "ready": False, "reason": "قیمت بازار تازه نیست"}

    results: Dict[str, Dict[str, Any]] = {}
    latest_candle_ts: Dict[str, float] = {}
    for timeframe in TIMEFRAMES:
        raw = market.fetch_candles(symbol, timeframe)
        closed = analysis.completed_candles(raw, timeframe, current)
        if not closed:
            return {"symbol": symbol, "ready": False,
                    "reason": f"کندل بسته‌شدهٔ {timeframe} موجود نیست"}
        seconds = analysis.TIMEFRAME_SECONDS[timeframe]
        candle_ts = float(closed[-1].get("time") or 0)
        if candle_ts <= 0 or current - candle_ts > seconds * 2.2 or candle_ts > current + 10:
            return {"symbol": symbol, "ready": False,
                    "reason": f"دادهٔ {timeframe} قدیمی یا دارای زمان نامعتبر است"}
        latest_candle_ts[timeframe] = candle_ts
        results[timeframe] = analysis.analyze_candles(closed)
        if not results[timeframe].get("ready"):
            return {"symbol": symbol, "ready": False,
                    "reason": results[timeframe].get("reason", "داده کافی نیست")}

    consensus = analysis.combine_timeframes(results)
    return {"symbol": symbol, "ready": True, "price": float(price),
            "ticker_source": ticker.get("source"), "ticker_ts": ticker_ts,
            "timeframes": results, "consensus": consensus,
            "last_candle_ts": latest_candle_ts}


def _plan(symbol: str, side: str, price: float,
          hourly: Dict[str, Any], equity: float,
          free_cash: Optional[float] = None,
          risk_scale: float = 1.0,
          risk_pct: float = 0.35,
          max_leverage: float = MAX_LEVERAGE,
          max_margin_pct: float = 2.0,
          max_free_cash_pct: float = 4.0) -> Optional[Dict[str, float]]:
    """Size a virtual order from a fixed loss budget and ATR stop distance."""
    atr = float(hourly.get("atr14") or 0)
    if atr <= 0 or price <= 0 or equity <= 0 or side not in ("LONG", "SHORT"):
        return None
    stop_distance = max(atr * 1.7, price * 0.003)
    risk_scale = max(0.0, min(1.0, float(risk_scale)))
    risk_pct = max(0.10, min(0.50, float(risk_pct)))
    max_leverage = max(1.0, min(MAX_LEVERAGE, float(max_leverage)))
    if risk_scale <= 0:
        return None
    risk_budget = equity * (risk_pct / 100.0) * risk_scale
    notional_from_risk = risk_budget * price / stop_distance
    notional_cap = equity * 0.12 * risk_scale
    notional = min(notional_from_risk, notional_cap)
    leverage = max_leverage
    if free_cash is None:
        free_cash = float(store.get_wallet().get("balance") or 0)
    free_cash = max(0.0, float(free_cash))
    margin = min(notional / leverage,
                 free_cash * max(0.5, min(10.0, max_free_cash_pct)) / 100.0,
                 equity * max(0.5, min(5.0, max_margin_pct)) / 100.0)
    if margin < 0.25:
        return None
    notional = margin * leverage
    quantity = notional / price
    actual_risk = quantity * stop_distance
    if actual_risk > risk_budget * 1.001:
        return None
    if side == "LONG":
        sl = price - stop_distance
        tp1 = price + stop_distance
        tp2 = price + stop_distance * 1.8
    else:
        sl = price + stop_distance
        tp1 = price - stop_distance
        tp2 = price - stop_distance * 1.8
    if min(sl, tp1, tp2) <= 0:
        return None
    trail_pct = max(0.25, min(3.0, stop_distance / price * 100.0 * 0.8))
    return {"leverage": leverage, "margin": margin, "sl": sl,
            "tp1": tp1, "tp2": tp2, "trail_pct": trail_pct,
            "risk_budget": risk_budget, "actual_risk": actual_risk,
            "stop_distance": stop_distance, "quantity": quantity,
            "notional": notional}


def scan_once(symbols: Optional[List[str]] = None, now: Optional[float] = None) -> Dict[str, Any]:
    """Run one watchlist scan and open only validated local demo positions."""
    stamp = float(now if now is not None else time.time())
    watch = _watch_symbols(symbols)
    config = get_auto_config()
    existing = store.list_open_positions()
    auto_open = [p for p in existing if p.get("source") == "auto"]
    profile = learning_engine.adaptive_profile()
    effective_min_score = max(config["min_confluence"], int(profile.get("min_confluence") or 70))
    result: Dict[str, Any] = {
        "checked": 0, "opened": [], "skipped": [], "evaluated": [],
        "adaptive_profile": profile, "config": config, "watchlist": watch,
        "message": "اسکن انجام نشد", "generated_ts": int(stamp),
    }
    if not watch:
        result["message"] = "در واچ‌لیست نماد واجد شرایطی برای اسکن خودکار وجود ندارد؛ فلزات و نفت فقط دستی و دمو هستند."
        return result
    if mem is not None:
        try:
            mem.refresh_if_new_trades()  # automatic retraining when a trade closed
        except Exception:
            pass
    dd = ai_core.drawdown_state()
    result["drawdown"] = dd
    if profile.get("auto_paused"):
        result["message"] = profile.get("note") or "اسکن خودکار دمو موقتاً متوقف است"
        result["paused"] = True
        return result
    if dd.get("paused"):
        result["message"] = (f"محافظ سرمایه: افت {dd['drawdown_pct']:.1f}% از قله؛ "
                             "اسکنر خودکار دمو تا بازبینی ژورنال متوقف است")
        result["paused"] = True
        return result
    if len(auto_open) >= config["max_positions"]:
        result["message"] = f"سقف {config['max_positions']} پوزیشن خودکار دمو از قبل پر است"
        result["capacity_full"] = True
        return result
    equity = float(store.get_wallet().get("balance") or 0)
    if equity <= 0:
        result["message"] = "موجودی آزاد دمو کافی نیست"
        return result

    occupied = set()
    for position in existing:
        try:
            occupied.add(market.normalize_symbol(position.get("symbol", ""))[1])
        except ValueError:
            continue

    candidates = []
    with ThreadPoolExecutor(max_workers=min(5, len(watch) or 1)) as pool:
        jobs = {pool.submit(inspect_symbol, symbol, stamp): symbol for symbol in watch}
        for future in as_completed(jobs):
            symbol = jobs[future]
            result["checked"] += 1
            try:
                item = future.result()
            except Exception as exc:
                reason = str(exc)[:100]
                result["skipped"].append((symbol, reason))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": reason})
                continue
            if not item.get("ready"):
                reason = item.get("reason", "داده کافی نیست")
                result["skipped"].append((symbol, reason))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": reason})
                continue
            consensus = item.get("consensus") or {}
            if not consensus.get("aligned"):
                reason = "سه بازهٔ ۱۵ دقیقه، ۱ ساعت و ۴ ساعت هم‌جهت نیستند"
                result["skipped"].append((symbol, reason))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": reason})
                continue
            pair = market.normalize_symbol(item["symbol"])[1]
            if pair in occupied:
                reason = "برای این نماد پوزیشن باز وجود دارد"
                result["skipped"].append((symbol, reason))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": reason})
                continue
            if store.auto_cooldown_active(pair, config["cooldown_seconds"]):
                reason = f"وقفهٔ ایمنی {config['cooldown_hours']:g} ساعته هنوز تمام نشده"
                result["skipped"].append((symbol, reason))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": reason})
                continue
            score = min(int(item["timeframes"][tf].get("confluence_score") or 0) for tf in TIMEFRAMES)
            if score < effective_min_score:
                reason = f"امتیاز هم‌گرایی {score} از حداقل لازم {effective_min_score} کمتر است"
                result["skipped"].append((symbol, reason))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": reason,
                                            "score": score})
                continue
            assessment = ai_core.assess_candidate(
                symbol, consensus.get("direction"), score,
                item["timeframes"]["1hour"], mem)
            item["assessment"] = assessment
            if not assessment["allow"] or score < effective_min_score + assessment["extra_score"]:
                why = " ".join(assessment["explain"][-1:]) or "رد شده توسط هستهٔ هوش"
                result["skipped"].append((symbol, why))
                result["evaluated"].append({"symbol": symbol, "status": "skip", "reason": why,
                                            "score": score, "explain": assessment["explain"]})
                ai_core.log_decision({"symbol": symbol, "side": consensus.get("direction"),
                                      "action": "rejected_by_core", "regime": assessment["regime"],
                                      "score": score, "why": why})
                continue
            boost = 0.0
            if mem is not None:
                try:
                    boost = max(0.0, float(mem.symbol_priority_boost(symbol))) * 8.0  # rank only
                except Exception:
                    boost = 0.0
            adj = int(max(0, min(100, score + boost)))
            item["score"] = adj
            item["memory_boost"] = boost
            candidates.append((adj, item))
            result["evaluated"].append({"symbol": symbol, "status": "candidate", "score": score,
                                        "direction": consensus.get("direction"),
                                        "source": item.get("ticker_source")})

    candidates.sort(key=lambda pair: (pair[0], pair[1].get("ticker_ts", 0)), reverse=True)
    open_capacity = max(0, config["max_positions"] - len(auto_open))
    for score, item in candidates[:open_capacity]:
        side = item["consensus"]["direction"]
        px = float(item["price"])
        free_cash = float(store.get_wallet().get("balance") or 0)
        assessment = item.get("assessment") or {"explain": [], "risk_mult": 1.0, "regime": "unknown"}
        item["score"] = score
        gate = _ai_gate_review(item, assessment)
        gate_tag = "none"
        gate_mult = 1.0
        if gate is not None:
            gate_tag = gate["verdict"] if gate.get("ok") else "unavailable"
            assessment["explain"].append(
                f"نظر مدل ابری ({gate['mode']}): {gate['verdict']} · اطمینان {gate['confidence']} · {gate['reason']}")
            skip_reason = None
            if gate["mode"] == "autopilot" and not gate.get("ok"):
                skip_reason = "اتوپایلوت AI: پاسخ مدل در دسترس نبود؛ بدون تصمیم AI ورودی انجام نمی‌شود"
            elif gate.get("ok") and gate["mode"] in ("veto", "autopilot") and gate["verdict"] == "veto":
                skip_reason = "مدل ابری ورود را وتو کرد: " + gate["reason"]
            if skip_reason:
                result["skipped"].append((item["symbol"], skip_reason))
                result["evaluated"].append({"symbol": item["symbol"], "status": "vetoed",
                                            "reason": skip_reason, "score": score,
                                            "explain": assessment["explain"]})
                ai_core.log_decision({"symbol": item["symbol"], "side": side, "action": "vetoed",
                                      "regime": assessment["regime"], "score": score,
                                      "gate": gate_tag, "why": gate["reason"]})
                continue
            if gate.get("ok") and gate["mode"] in ("veto", "autopilot"):
                if gate["verdict"] == "reduce":
                    gate_mult = 0.5
                if gate["mode"] == "autopilot":
                    gate_mult = min(gate_mult, float(gate.get("size_mult", 1.0)))
                    if gate.get("side") in ("LONG", "SHORT") and gate["side"] != side:
                        assessment["explain"].append(f"AI جهت را از {side} به {gate['side']} تغییر داد.")
                        side = gate["side"]
        # Reduce-only composition: every factor is <= 1.0, so nothing can enlarge risk.
        scale = 1.0
        try:
            scale = float(profile.get("risk_scale", 1.0))
        except (TypeError, ValueError):
            scale = 1.0
        if mem is not None:
            try:
                scale = min(scale, float(mem.risk_scale()))
            except Exception:
                pass
        scale = max(0.0, min(1.0, scale * dd.get("risk_mult", 1.0)
                             * float(assessment.get("risk_mult", 1.0)) * gate_mult))
        plan = _plan(
            item["symbol"], side, px, item["timeframes"]["1hour"], equity,
            free_cash=free_cash, risk_scale=scale,
            risk_pct=config["risk_pct"], max_leverage=config["max_leverage"],
            max_margin_pct=config["max_margin_pct_per_position"],
            max_free_cash_pct=config["max_free_cash_pct_per_position"],
        )
        if not plan:
            reason = "اندازهٔ موقعیت با بودجهٔ ریسک، مارجین آزاد و هزینه‌ها سازگار نشد"
            result["skipped"].append((item["symbol"], reason))
            continue
        try:
            opened = store.open_position(
                item["symbol"], side, px, plan["leverage"], plan["margin"],
                tp1=plan["tp1"], tp2=plan["tp2"], sl=plan["sl"],
                trail_pct=plan["trail_pct"], source="auto",
                note=(f"paper MTF score={score}; risk={config['risk_pct']:.2f}%; "
                      f"stop_atr={plan['stop_distance']:.8g}; regime={assessment.get('regime', 'unknown')}; "
                      f"gate={gate_tag}; scale={scale:.2f}; no live order"),
            )
            opened_row = {
                "symbol": item["symbol"], "side": side, "id": opened["id"],
                "score": score, "risk_budget": plan["risk_budget"],
                "actual_risk": plan["actual_risk"], "margin": plan["margin"],
                "leverage": plan["leverage"], "entry": px, "sl": plan["sl"],
                "tp1": plan["tp1"], "tp2": plan["tp2"],
            }
            result["opened"].append(opened_row)
            result["evaluated"].append({"symbol": item["symbol"], "status": "opened",
                                        "score": score, "direction": side, "position_id": opened["id"],
                                        "explain": assessment["explain"], "risk_scale": scale})
            ai_core.log_decision({"symbol": item["symbol"], "side": side, "action": "opened",
                                  "regime": assessment["regime"], "score": score, "gate": gate_tag,
                                  "pos_id": opened["id"], "risk_scale": round(scale, 3),
                                  "why": "; ".join(assessment["explain"])[:160]})
            occupied.add(market.normalize_symbol(item["symbol"])[1])
            equity = max(0.0, equity - plan["margin"])
        except Exception as exc:
            reason = str(exc)[:100]
            result["skipped"].append((item["symbol"], reason))
            result["evaluated"].append({"symbol": item["symbol"], "status": "error", "reason": reason})

    result["message"] = (f"{len(result['opened'])} پوزیشن دمو باز شد" if result["opened"]
                         else "شرط معتبر و هم‌جهت برای ورود دمو پیدا نشد")
    result["adaptive_note"] = profile.get("note")
    result["effective_min_confluence"] = effective_min_score
    result["remaining_auto_capacity"] = max(0, config["max_positions"] - len(auto_open) - len(result["opened"]))
    return result


def format_scan_report(result: Dict[str, Any]) -> str:
    """Human-readable audit note consumed by the UI and local coach."""
    config = result.get("config") or get_auto_config()
    opened = result.get("opened") or []
    skipped = result.get("skipped") or []
    evaluated = result.get("evaluated") or []
    lines = [
        "گزارش ممیزی Auto-Trade دمو KALVO",
        time.strftime("زمان: %Y-%m-%d %H:%M:%S", time.localtime(result.get("generated_ts") or time.time())),
        f"نمادهای بررسی‌شده: {', '.join(result.get('watchlist') or []) or '—'}",
        f"اسکن: {result.get('checked', 0)} · کاندیدا/ارزیابی: {len(evaluated)} · بازشده: {len(opened)} · ردشده: {len(skipped)}",
        f"تنظیمات: ریسک {config.get('risk_pct', 0.35):.2f}% · حداقل امتیاز {result.get('effective_min_confluence', config.get('min_confluence'))} · سقف پوزیشن {config.get('max_positions')} · اهرم مجاز شبیه‌سازی {config.get('max_leverage')}×",
        str(result.get("message") or "—"),
    ]
    for row in opened:
        lines.append(
            f"ورود دمو #{row['id']}: {row['symbol']} {row['side']} · قیمت {row['entry']:.8g} · "
            f"مارجین {row['margin']:.2f} · ریسک محاسباتی {row['actual_risk']:.3f} USDT · "
            f"SL {row['sl']:.8g} · TP1 {row['tp1']:.8g}"
        )
    if (result.get("drawdown") or {}).get("state") not in (None, "ok"):
        d = result["drawdown"]
        lines.append(f"محافظ سرمایه: {d['state']} · افت {d['drawdown_pct']:.1f}% از قله")
    for row in evaluated:
        if row.get("status") in ("opened", "vetoed") and row.get("explain"):
            lines.append(f"چرا {row['symbol']}؟")
            lines.extend("  - " + x for x in row["explain"])
    if skipped:
        lines.append("دلایل رد:")
        lines.extend(f"• {symbol}: {reason}" for symbol, reason in skipped[:12])
    if result.get("adaptive_note"):
        lines.append("بازخورد ژورنال: " + str(result["adaptive_note"]))
    lines.append("این اسکن فقط سفارش مجازی در دفترکل محلی می‌سازد و به صرافی سفارش نمی‌فرستد.")
    return "\n".join(lines)
