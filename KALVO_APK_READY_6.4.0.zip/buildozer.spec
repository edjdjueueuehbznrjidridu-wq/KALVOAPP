[app]
title = KALVO Market Intelligence
package.name = kalvomax
package.domain = org.kalvo.lab
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,txt
source.exclude_dirs = tests,bin,.git,__pycache__,.buildozer,.github
version = 6.4.0
requirements = python3,kivy==2.2.1,certifi,pyjnius
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 33
android.minapi = 24
android.ndk = 25b
android.sdk = 33
android.accept_sdk_license = True
android.archs = arm64-v8a
android.allow_backup = False
p4a.branch = v2024.01.21
android.release_artifact = apk
android.debug_artifact = apk

[buildozer]
log_level = 2
warn_on_root = 0
bin_dir = ./bin
