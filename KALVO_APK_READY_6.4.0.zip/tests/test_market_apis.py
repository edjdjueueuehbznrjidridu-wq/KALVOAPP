import unittest
from unittest.mock import patch

from apex import market_apis as mapi


class MarketApiTests(unittest.TestCase):
    def setUp(self):
        mapi.clear_cache()

    def tearDown(self):
        mapi.clear_cache()

    def test_failed_ticker_payload_is_not_cached(self):
        calls = []

        def request():
            calls.append(1)
            if len(calls) == 1:
                return {"price": None, "error": "temporary outage"}
            return {"price": 123.45, "source": "mock"}

        with patch.object(mapi.time, "monotonic", return_value=100.0):
            first = mapi._cached("ticker:test", 30, request)
            second = mapi._cached("ticker:test", 30, request)

        self.assertIsNone(first["price"])
        self.assertEqual(second["price"], 123.45)
        self.assertEqual(len(calls), 2)

    def test_valid_ticker_payload_is_cached(self):
        calls = []

        def request():
            calls.append(1)
            return {"price": 12.5, "source": "mock"}

        with patch.object(mapi.time, "monotonic", return_value=100.0):
            first = mapi._cached("ticker:good", 30, request)
            second = mapi._cached("ticker:good", 30, request)

        self.assertEqual(first, second)
        self.assertEqual(len(calls), 1)

    def test_ticker_freshness_is_recomputed_on_each_read(self):
        raw = {"price": 100.0, "source": "mock", "ts": 1_000, "stale": False}
        with patch.object(mapi, "_cached", return_value=raw), \
             patch.object(mapi.time, "time", return_value=1_010):
            fresh = mapi.get_ticker("BTC")
        self.assertEqual(fresh["status"], "fresh")
        self.assertFalse(fresh["stale"])
        with patch.object(mapi, "_cached", return_value=raw), \
             patch.object(mapi.time, "time", return_value=1_100):
            stale = mapi.get_ticker("BTC")
        self.assertEqual(stale["status"], "stale")
        self.assertTrue(stale["stale"])
        self.assertEqual(stale["age_seconds"], 100.0)

    def test_live_price_rejects_explicitly_stale_ticker(self):
        with patch.object(mapi, "get_ticker", return_value={
            "price": 100.0, "status": "stale", "stale": True,
        }):
            self.assertIsNone(mapi.get_live_price("BTC"))

    def test_zero_funding_value_remains_cacheable(self):
        calls = []

        def request():
            calls.append(1)
            return 0.0

        with patch.object(mapi.time, "monotonic", return_value=100.0):
            mapi._cached("funding:zero", 30, request)
            mapi._cached("funding:zero", 30, request)

        self.assertEqual(len(calls), 1)

    def test_rich_snapshot_calculates_depth_imbalance(self):
        book = {
            "bids": [[100.0, 2.0], [99.0, 1.0]],
            "asks": [[101.0, 1.0], [102.0, 1.0]],
            "ts": 123, "source": "test",
        }
        ticker = {"base": "BTC", "price": 100.5, "bid": 100.0, "ask": 101.0,
                  "source": "test", "ts": 123}
        with patch.object(mapi, "get_ticker", return_value=ticker), \
             patch.object(mapi, "fetch_orderbook", return_value=book), \
             patch.object(mapi, "funding_rate", return_value=None), \
             patch.object(mapi, "open_interest", return_value=None):
            snapshot = mapi.rich_snapshot("BTC")
        self.assertGreater(snapshot["depth_imbalance_pct"], 0)
        self.assertAlmostEqual(snapshot["depth_imbalance_pct"],
                               (299.0 - 203.0) / (299.0 + 203.0) * 100.0)

    def test_symbol_normalization_is_explicit_about_quote(self):
        self.assertEqual(mapi.normalize_symbol("btc")[0], "BTC")
        with self.assertRaises(ValueError):
            mapi.normalize_symbol("BTC-EUR")

    def test_unsupported_timeframe_is_rejected_instead_of_silently_using_one_hour(self):
        with self.assertRaisesRegex(ValueError, "تایم‌فریم پشتیبانی نمی‌شود"):
            mapi.fetch_candles("BTC", "10min")


if __name__ == "__main__":
    unittest.main()
