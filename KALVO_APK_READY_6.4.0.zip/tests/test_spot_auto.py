import unittest
from unittest.mock import patch
from apex import spot_auto


class SpotAutoTests(unittest.TestCase):
    def test_stale_market_price_never_creates_spot_demo_order(self):
        with patch.object(spot_auto.market, 'get_ticker', return_value={
            'price': 100.0, 'ts': 1, 'base': 'BTC'
        }), patch.object(spot_auto.store, 'spot_market_order') as order:
            result = spot_auto.scan_once('BTC', now=1000)
        self.assertEqual(result['action'], 'HOLD')
        order.assert_not_called()

    def test_aligned_strong_long_frames_only_create_a_bounded_demo_order(self):
        stamp = 100_000
        strong = {'ready': True, 'signal': 'LONG_BIAS', 'confluence_score': 82,
                  'volatility_ratio': 1.2}
        with patch.object(spot_auto.market, 'get_ticker', return_value={
            'price': 100.0, 'ts': stamp, 'base': 'BTC'
        }), patch.object(spot_auto.market, 'fetch_candles', return_value=[{'close': 100, 'time': stamp - 10}]), \
             patch.object(spot_auto.analysis, 'completed_candles', return_value=[{'close': 100, 'time': stamp - 10}]), \
             patch.object(spot_auto.analysis, 'analyze_candles', return_value=strong), \
             patch.object(spot_auto.store, 'get_spot_balances', return_value=[
                 {'asset': 'USDT', 'free': 1000.0}, {'asset': 'BTC', 'free': 0.0}
             ]), patch.object(spot_auto.store, 'get_setting', return_value='0'), \
             patch.object(spot_auto.store, 'spot_market_order', return_value={'quantity': 1.0}) as order, \
             patch.object(spot_auto.store, 'set_setting'):
            result = spot_auto.scan_once('BTC', now=stamp)
        self.assertEqual(result['action'], 'BUY')
        self.assertEqual(order.call_args.args[1], 'BUY')
        self.assertEqual(order.call_args.args[2], 100.0)  # 10% of virtual USDT balance

    def test_weak_signal_never_triggers_auto_spot_order(self):
        stamp = 100_000
        weak = {'ready': True, 'signal': 'LONG_BIAS', 'confluence_score': 45,
                'volatility_ratio': 1.1}
        with patch.object(spot_auto.market, 'get_ticker', return_value={
            'price': 100.0, 'ts': stamp, 'base': 'BTC'
        }), patch.object(spot_auto.market, 'fetch_candles', return_value=[{'close': 100, 'time': stamp - 10}]), \
             patch.object(spot_auto.analysis, 'completed_candles', return_value=[{'close': 100, 'time': stamp - 10}]), \
             patch.object(spot_auto.analysis, 'analyze_candles', return_value=weak), \
             patch.object(spot_auto.store, 'get_spot_balances', return_value=[
                 {'asset': 'USDT', 'free': 1000.0}, {'asset': 'BTC', 'free': 0.0}
             ]), patch.object(spot_auto.store, 'get_setting', return_value='0'), \
             patch.object(spot_auto.store, 'spot_market_order') as order:
            result = spot_auto.scan_once('BTC', now=stamp)
        self.assertEqual(result['action'], 'HOLD')
        order.assert_not_called()
