# -*- coding: utf-8 -*-
"""KALVO Hybrid Intelligence: local coach + optional Coarena cloud models."""
from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from apex import market_assistant as local
from apex import coarena_ai as cloud


SYSTEM_FA = (
    "تو تحلیل‌گر ارشد بازار کریپتو برای اپ آموزشی KALVO هستی. "
    "پاسخ‌ها باید فارسی، دقیق، بدون وعده سود قطعی و با تاکید بر ریسک باشد. "
    "از دادهٔ تکنیکال و وضعیت حساب دمو که به تو داده می‌شود استفاده کن. "
    "هرگز ادعا نکن سفارش واقعی به صرافی می‌فرستی؛ همه چیز مجازی/آموزشی است."
)


_ANALYSIS_KEYS = (
    "signal", "trend", "market_regime", "confluence_score", "directional_score",
    "rsi14", "macd_hist", "adx14", "atr14", "atr_pct", "volatility_state",
    "ema20", "ema50", "ema200", "bb_width_pct", "volume_ratio", "momentum_5_pct",
    "support_50", "resistance_50", "warning",
)


def local_answer(question: str, ctx: Optional[dict] = None) -> str:
    ctx = ctx or {}
    analysis = ctx.get("analysis")
    try:
        return local.answer_question(question, analysis=analysis)
    except TypeError:
        return local.answer_question(question)



def cloud_available(api_key: str = "") -> bool:
    try:
        key = cloud.resolve_key(api_key)
    except Exception:
        key = api_key or ""
    return bool(key and len(key.strip()) >= 8)


def build_context_block(
    symbol: str,
    analysis: Optional[dict],
    ticker: Optional[dict],
    positions: Optional[list],
    wallet: Optional[dict],
    learning_summary: Optional[str] = None,
    share_account: bool = False,
) -> str:
    """Build the cloud prompt context.

    Privacy: by default NO per-position or balance details leave the device; only
    market data and aggregate counts are sent. Set share_account=True (setting
    ``ai_share_account=1``) to include positions and equity.
    """
    parts: List[str] = [f"نماد: {symbol}"]
    if ticker:
        parts.append(
            f"قیمت: {ticker.get('price')} | منبع: {ticker.get('source')} | "
            f"تغییر ۲۴س: {ticker.get('change_pct')}"
        )
    if analysis:
        parts.append("تحلیل تکنیکال (خلاصه):")
        for k in _ANALYSIS_KEYS:
            if analysis.get(k) is not None:
                parts.append(f"  - {k}: {analysis[k]}")
        # dump compact remaining keys
        extra = {k: v for k, v in analysis.items() if k not in set(_ANALYSIS_KEYS) | {"candles"}
                 and not isinstance(v, (list, dict))}
        if extra:
            parts.append("  - سایر: " + json.dumps(extra, ensure_ascii=False)[:500])
    if share_account:
        if positions:
            parts.append(f"پوزیشن‌های باز دمو ({len(positions)}):")
            for p in positions[:12]:
                parts.append(
                    f"  - {p.get('symbol')} {p.get('side')} qty={p.get('qty')} "
                    f"entry={p.get('entry')} lev={p.get('leverage')} "
                    f"tp={p.get('tp')} sl={p.get('sl')} uPnL={p.get('upnl')}"
                )
        if wallet:
            parts.append(
                f"اکوئیتی دمو: {wallet.get('equity')} | آزاد: {wallet.get('free')} | "
                f"قفل: {wallet.get('locked')}"
            )
    elif positions:
        parts.append(f"تعداد پوزیشن‌های باز دمو: {len(positions)} (جزئیات حساب ارسال نمی‌شود)")
    if learning_summary:
        parts.append("یادگیری از تاریخچه: " + learning_summary[:400])
    return "\n".join(parts)


def cloud_analyze(
    api_key: str,
    model: str,
    symbol: str,
    user_prompt: str,
    context_block: str,
    retries: int = 3,
) -> str:
    messages = [
        {"role": "system", "content": SYSTEM_FA},
        {
            "role": "user",
            "content": (
                f"بافت بازار و حساب:\n{context_block}\n\n"
                f"درخواست کاربر دربارهٔ {symbol}:\n{user_prompt}\n\n"
                "خروجی ساخت‌یافته بده: ۱) سوگیری ۲) دلایل ۳) ریسک‌ها ۴) سناریو صعود/نزول "
                "۵) نکتهٔ مدیریت پوزیشن دمو — بدون توصیهٔ قطعی ورود با پول واقعی."
            ),
        },
    ]
    last_err = None
    for attempt in range(max(1, retries)):
        try:
            return cloud.chat(
                api_key=api_key,
                messages=messages,
                model=model or cloud.DEFAULT_MODEL,
                temperature=0.35,
                max_tokens=4096,
                reasoning_effort="high",
                retries=2,
            )
        except Exception as exc:  # noqa: BLE001
            last_err = exc
            continue
    raise RuntimeError(f"Coarena پس از {retries} تلاش ناموفق: {last_err}")


def hybrid_reply(
    mode: str,
    question: str,
    api_key: str,
    model: str,
    ctx: dict,
) -> Dict[str, Any]:
    """mode: local | cloud | both"""
    local_txt = local_answer(question, ctx)
    if mode == "local" or not cloud_available(api_key):
        return {"mode": "local", "text": local_txt, "cloud": None}
    try:
        cloud_txt = cloud_analyze(
            api_key=api_key,
            model=model or cloud.DEFAULT_MODEL,
            symbol=str(ctx.get("symbol") or "BTC"),
            user_prompt=question,
            context_block=ctx.get("context_block") or "",
            retries=3,
        )
        if mode == "cloud":
            return {"mode": "cloud", "text": cloud_txt, "cloud": cloud_txt, "local": local_txt}
        merged = (
            "—— هوش ابری KALVO ——\n"
            + cloud_txt
            + "\n\n—— پایگاه دانش محلی ——\n"
            + local_txt
        )
        return {"mode": "both", "text": merged, "cloud": cloud_txt, "local": local_txt}
    except Exception as exc:  # noqa: BLE001
        return {
            "mode": "local_fallback",
            "text": f"[ابر در دسترس نبود: {exc}]\n\n" + local_txt,
            "cloud": None,
            "local": local_txt,
        }


GATE_SYSTEM = (
    "You are a risk reviewer for a PAPER-trading simulator. You receive one candidate "
    "trade produced by rule-based analysis. You may only approve it, reduce its size, "
    "or veto it. You can never increase size. Reply with ONE JSON object only: "
    '{"verdict":"approve|reduce|veto","confidence":0-100,"reason":"<=140 chars"}'
)


AUTOPILOT_SYSTEM = (
    "You are the decision-maker of a PAPER-trading simulator (no real money). Rule-based "
    "analysis proposes one candidate; YOU make the final call. Choose side LONG or SHORT "
    "(you may disagree with the proposed side), a size_mult between 0.25 and 1.0, or veto. "
    "Position size is hard-capped by code, so size_mult can only shrink it. Reply with ONE "
    'JSON object only: {"verdict":"approve|reduce|veto","side":"LONG|SHORT",'
    '"size_mult":0.25-1.0,"confidence":0-100,"reason":"<=140 chars"}'
)


def parse_gate_reply(text: str) -> Dict[str, Any]:
    """Parse the cloud verdict defensively; anything malformed -> unavailable."""
    import re
    try:
        m = re.search(r"\{.*\}", text or "", re.S)
        data = json.loads(m.group(0)) if m else {}
        verdict = str(data.get("verdict", "")).strip().lower()
        if verdict not in ("approve", "reduce", "veto"):
            raise ValueError("bad verdict")
        conf = max(0, min(100, int(float(data.get("confidence", 50)))))
        side = str(data.get("side", "")).strip().upper()
        try:
            size = float(data.get("size_mult", 1.0))
        except (TypeError, ValueError):
            size = 1.0
        size = max(0.25, min(1.0, size))  # can never exceed the code-enforced budget
        return {"ok": True, "verdict": verdict, "confidence": conf,
                "side": side if side in ("LONG", "SHORT") else "",
                "size_mult": size, "reason": str(data.get("reason", ""))[:200]}
    except Exception:
        return {"ok": False, "verdict": "unavailable", "confidence": 0,
                "reason": "پاسخ مدل قابل‌تفسیر نبود"}


def cloud_gate(api_key: str, model: str, context_block: str, symbol: str,
               side: str, score: int, regime: str, autopilot: bool = False) -> Dict[str, Any]:
    """Ask the cloud model to approve/reduce/veto ONE candidate. Never raises."""
    prompt = (
        f"Candidate: {symbol} {side}, rule-based confluence score {score}/100, "
        f"market regime {regime}.\nMarket context:\n{context_block}\n"
        "Return the JSON verdict now."
    )
    try:
        text = cloud.chat(
            api_key=api_key,
            messages=[{"role": "system", "content": AUTOPILOT_SYSTEM if autopilot else GATE_SYSTEM},
                      {"role": "user", "content": prompt}],
            model=model or cloud.DEFAULT_MODEL,
            temperature=0.1, max_tokens=300, retries=2, timeout=30,
        )
        return parse_gate_reply(text)
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "verdict": "unavailable", "confidence": 0,
                "reason": f"ابر در دسترس نبود: {str(exc)[:80]}"}
